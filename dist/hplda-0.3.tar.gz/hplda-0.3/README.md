# HLDA
This is an implementation of Hierarchical Latent Dirichlet Allocation
