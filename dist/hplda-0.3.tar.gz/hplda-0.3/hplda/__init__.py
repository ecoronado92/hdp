import hplda.data_preproc

def lda():
    print('This is an LDA package')